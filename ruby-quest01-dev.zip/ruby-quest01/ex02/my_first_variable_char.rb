my_letter = 'c'
puts(my_letter)