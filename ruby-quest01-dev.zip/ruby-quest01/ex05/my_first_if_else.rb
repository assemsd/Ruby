nbr = 10

if(nbr > 20)
    puts("nbr is greater than 20")
else
    puts("nbr is less than 20")
end