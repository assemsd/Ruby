my_index = 0
my_index += 1
puts(my_index)
my_index -= 1
my_index -= 1
puts(my_index)
my_index += 1
my_index += 1
my_index += 1
puts(my_index)