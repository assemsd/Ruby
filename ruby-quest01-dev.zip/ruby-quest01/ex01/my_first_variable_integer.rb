person_age = 34
puts(person_age)