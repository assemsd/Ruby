my_age = 34;
my_name = "Luke";
my_comma = ',';

puts("Hello #{my_name}#{my_comma} I'm #{my_age} years old.")